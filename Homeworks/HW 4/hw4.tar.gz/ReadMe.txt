Hello

	The input file first number should have the size as the first number.


