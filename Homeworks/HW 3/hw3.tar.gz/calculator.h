#ifndef CALCULATOR_H
#define CALCULATOR_H

#include "stack.h"

char* to_postfix(char* equ);
int eval(char* equ);

#endif
